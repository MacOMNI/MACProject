//
//  BaseModel.m
//  WeiSchoolTeacher
//
//  Created by MacKun on 16/1/19.
//  Copyright © 2016年 MacKun. All rights reserved.
//

#import "BaseModel.h"

@implementation BaseModel

@end
