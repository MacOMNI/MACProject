//
//  HJCornerRadius.h
//  HJImageViewDemo
//
//  Created by haijiao on 16/3/10.
//  Copyright © 2016年 olinone. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIImageView (HJCornerRadius)

@property (nonatomic, assign) CGFloat aliCornerRadius;

@end
