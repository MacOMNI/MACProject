//
//  UIImageHeader.h
//  MACProject
//
//  Created by MacKun on 16/8/12.
//  Copyright © 2016年 com.mackun. All rights reserved.
//

#ifndef UIImageHeader_h
#define UIImageHeader_h

#import "UIImage+Additions.h"
#import "UIImage+SuperCompress.h"


#endif /* UIImageHeader_h */
