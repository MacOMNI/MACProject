//
//  MACRefreshHeader.h
//  WeiSchoolTeacher
//
//  Created by MacKun on 16/1/11.
//  Copyright © 2016年 MacKun. All rights reserved.
//

#import <MJRefresh/MJRefresh.h>

@interface MACRefreshHeader : MJRefreshGifHeader

@end
