//
//  UIUnderLineLabelLabel.h
//  Component
//
//  Created by MacKun on 15/7/9.
//  Copyright (c) 2015年 MacKun. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIUnderLineLabelLabel : UILabel

@end
